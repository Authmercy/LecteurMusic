import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListealbumPage } from './listealbum.page';

const routes: Routes = [
  {
    path: '',
    component: ListealbumPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ListealbumPageRoutingModule {}
