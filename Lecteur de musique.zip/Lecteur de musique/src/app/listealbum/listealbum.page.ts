import { Component, OnInit } from '@angular/core';
import { SongsService } from "../providers/songs.service";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-listealbum',
  templateUrl: './listealbum.page.html',
  styleUrls: ['./listealbum.page.scss'],
})
export class ListealbumPage implements OnInit {
  album!: any;
  listmusic1: any[]=[];
  Tsongs: any[] = [];
  TsongsL: any[] = [];
  pending: boolean = false;
  Titre1='';
  alb:any
  constructor(
    private song: SongsService,
    private route: Router,
    private router: ActivatedRoute
  ) { }

  removeQuotes(str: string): string {
    return str.replace(/"/g, '');
  }

  ngOnInit() {
    console.log(localStorage)
    let alb = localStorage.getItem("al");

    if(alb){
      this.alb=JSON.parse(alb)
      this.Titre1=this.alb.nomAlbum
    }
    this.album = alb;
    this.album = this.removeQuotes(this.album);
    this.song.getListOfMusics().subscribe((rep: any) => {
      this.Tsongs = rep;
      this.listmusic1 = this.Tsongs.filter((song: any) => {
        return song.Album.idAlbum == this.alb.idAlbum ;
      });

      setTimeout(() => {
        this.pending = true;
      }, 800);

    });

    localStorage.removeItem("al")
  }

  details(musi: any) {
    localStorage.setItem("dt", JSON.stringify(musi));
    this.route.navigate(['onglets/album/listealbum/lecture']);
  }
}
