import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListealbumPageRoutingModule } from './listealbum-routing.module';

import { ListealbumPage } from './listealbum.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListealbumPageRoutingModule
  ],
  declarations: [ListealbumPage]
})
export class ListealbumPageModule {}
