import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ListealbumPage } from './listealbum.page';

describe('ListealbumPage', () => {
  let component: ListealbumPage;
  let fixture: ComponentFixture<ListealbumPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ListealbumPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
