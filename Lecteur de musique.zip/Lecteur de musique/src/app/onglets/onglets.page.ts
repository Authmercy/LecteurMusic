import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onglets',
  templateUrl: './onglets.page.html',
  styleUrls: ['./onglets.page.scss'],
})
export class OngletsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
