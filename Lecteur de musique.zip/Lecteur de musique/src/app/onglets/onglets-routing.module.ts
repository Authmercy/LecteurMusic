import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OngletsPage } from './onglets.page';

const routes: Routes = [
  {
    path: '',
    component: OngletsPage,
    children:[
      // {
      //   path: '',
      //   loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
      // },
      {
        path: 'apropos',
        loadChildren: () => import('../apropos/apropos.module').then( m => m.AproposPageModule)
      },
      {
        path: 'album',
        loadChildren: () => import('../album/album.module').then( m => m.AlbumPageModule)
      },
      {
        path: 'home',
        loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
      },
      {
        path: 'home/dcategorie/lecture',
        loadChildren: () => import('../lecture/lecture.module').then( m => m.LecturePageModule)
      },
      {
        path: 'home/dcategorie',
        loadChildren: () => import('../dcategorie/dcategorie.module').then( m => m.DcategoriePageModule)
      },
      {
        path: 'album/listealbum',
        loadChildren: () => import('../listealbum/listealbum.module').then( m => m.ListealbumPageModule)
      },
      {
        path: 'album/listealbum/lecture',
        loadChildren: () => import('../lecture/lecture.module').then( m => m.LecturePageModule)
      },
    ]
  },
  {
    path: '',
    redirectTo: 'onglets',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OngletsPageRoutingModule {}
