import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DcategoriePage } from './dcategorie.page';

describe('DcategoriePage', () => {
  let component: DcategoriePage;
  let fixture: ComponentFixture<DcategoriePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(DcategoriePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
