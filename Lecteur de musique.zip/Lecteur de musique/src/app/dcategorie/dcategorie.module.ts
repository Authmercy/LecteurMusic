import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DcategoriePageRoutingModule } from './dcategorie-routing.module';

import { DcategoriePage } from './dcategorie.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DcategoriePageRoutingModule
  ],
  declarations: [DcategoriePage]
})
export class DcategoriePageModule {}
