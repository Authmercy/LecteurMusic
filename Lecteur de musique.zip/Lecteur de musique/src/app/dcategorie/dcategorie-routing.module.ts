import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DcategoriePage } from './dcategorie.page';

const routes: Routes = [
  {
    path: '',
    component: DcategoriePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DcategoriePageRoutingModule {}
