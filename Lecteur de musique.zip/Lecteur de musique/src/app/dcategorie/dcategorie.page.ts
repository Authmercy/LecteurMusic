import { Component, OnInit } from '@angular/core';
import { CategoriesService } from "../providers/categories.service";
import { SongsService } from "../providers/songs.service";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dcategorie',
  templateUrl: './dcategorie.page.html',
  styleUrls: ['./dcategorie.page.scss'],
})
export class DcategoriePage implements OnInit {
  categorie!: any;
  pending: boolean= false
  Tsongs: any[] = [];
  private Tsongscat: any[] = [];
  Tsongscatrech: any[] = [];

  constructor(
    private song: SongsService,
    private tcategorie: CategoriesService,
    private route: Router,
    private router: ActivatedRoute
  ) { }

  removeQuotes(str: string): string {
    return str.replace(/"/g, '');
  }
  listmusic: any[]=[];
  listmusic1: any[]=[];
  idAlbum =''
  listalbum: any[]=[];
  listalb : any[]=[];
  album : any;
isPlaying :boolean = false;
  musics: any[]=[];
  loader: any;

  cat: any;
  listeSon : any[]=[]
  source!: string | null;
sonsAlbum: any[]=[] 
  Titre= '';
  
  Titre1= '';
  ngOnInit() {

    let cat = localStorage.getItem("fn");

    this.categorie = cat;
    let idAlbum = localStorage.getItem("idAlbum")
    localStorage.removeItem("idAlbum");
    if(idAlbum){
      this.idAlbum = JSON.parse(idAlbum);
    }
    if(cat){
      this.cat=JSON.parse(cat)
      this.Titre1=this.cat.nom
    }


    localStorage.removeItem("fn")
    this.song.getListOfMusics().subscribe((sons : any)=>{
      this.pending = true;
    this.listmusic = sons;
       sons.forEach((son: any) => {
        if(this.source == "album"){
          if (son.idCategori == this.cat.idCategori ){
            this.listmusic.push(son);
            this.Titre = this.cat.nom
            localStorage.removeItem("idAlbum"); 
            localStorage.removeItem("key");
          }
          // if (son.Album.idAlbum == this.idAlbum){
          //   this.sonsAlbum.push(son);
          //   this.Titre = son.Album.nomAlbum != ""? son.Album.nomAlbum:"Album inconu";
          // }
        }else{
          if (son.idCategori == this.cat.idCategori ){
            this.listmusic1.push(son);
            this.Titre = this.cat.nom
            localStorage.removeItem("idAlbum"); 
            localStorage.removeItem("key");
          }
        }
        localStorage.removeItem("idAlbum"); 
        localStorage.removeItem("key");})


      });
  
    }

  details(musi: any) {
    localStorage.setItem("dt", JSON.stringify(musi));
    this.route.navigate(['onglets/home/dcategorie/lecture']);
  }

  
  onSearchChange(ev: any){
    
    let recherche: string = ev.detail.value;

    this.Tsongscatrech = this.Tsongscat.filter( song =>{
      let txt_search = song.nom;
      return txt_search.toLowerCase().indexOf(recherche.toLowerCase()) > -1;
    });

    }
}
