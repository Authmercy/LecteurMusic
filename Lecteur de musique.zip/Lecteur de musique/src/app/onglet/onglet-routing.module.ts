import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OngletPage } from './onglet.page';

const routes: Routes = [
  {
    path: 'onglet',
    component: OngletPage,
    children :[
      {
        path: '',
        redirectTo: 'onglets',
        pathMatch: 'full'
      },
  {
    path: 'album',
    loadChildren: () => import('../album/album.module').then( m => m.AlbumPageModule)
  },
  {
    path: 'apropos',
    loadChildren: () => import('../apropos/apropos.module').then( m => m.AproposPageModule)
  },
  {
    path: 'cat',
    loadChildren: () => import('../cat/cat.module').then( m => m.CatPageModule)
  },
  {
    path: 'folder/:folder',
    loadChildren: () => import('../folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'folder',
    loadChildren: () => import('../folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'albumvrai',
    loadChildren: () => import('../albumvrai/albumvrai.module').then( m => m.AlbumvraiPageModule)
  },
  {
    path: 'son-album',
    loadChildren: () => import('../son-album/son-album.module').then( m => m.SonAlbumPageModule)
  },
  {
    path: 'son-album/:Titre',
    loadChildren: () => import('../son-album/son-album.module').then( m => m.SonAlbumPageModule)
  },

  {
    path: 'album',
    loadChildren: () => import('../album/album.module').then( m => m.AlbumPageModule)
  },
  {
    path: 'album/:Titre',
    loadChildren: () => import('../album/album.module').then( m => m.AlbumPageModule)
  },
  {
    path: 'search',
    loadChildren: () => import('../search/search.module').then( m => m.SearchPageModule)
  },
  {
    path: '',
    loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
  },
  

{
  path: 'son',
  loadChildren: () => import('../son/son.module').then( m => m.SonPageModule)
},
{
  path: 'son/:Titre',
  loadChildren: () => import('../son/son.module').then( m => m.SonPageModule)
},
  {
    path: 'home',
    loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
  },
{
  path: 'home/son',
  loadChildren: () => import('../son/son.module').then( m => m.SonPageModule)
},

    ],
  
},
{
  path: '',
  redirectTo: 'onglet',
  pathMatch: 'full'
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OngletPageRoutingModule {}
