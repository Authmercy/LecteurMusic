import { Injectable,Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NativeAudio } from '@capacitor-community/native-audio';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { isPlatformBrowser } from '@angular/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class SongsService {
  categorie =  "afrourban";
  chemin= '';
  nom: any[] = [];

  enCours = '';
  sons: any[] = [];
  v = 1.0;

  music: any;
  isPlaying = false;
  constructor(private http:HttpClient) { }

  
  private listMusiques = this.http.get("assets/TP2_JSON_NAHSANG_MERCY/song.json");
  private musiqueUrl = 'assets/TP2_JSON_NAHSANG_MERCY/song.json';

async getAudioDuration(id : number){
  return NativeAudio.getDuration({assetId: String(id)})
}
            getListOfMusics(){
        
  return this.http.get("assets/TP2_JSON_NAHSANG_MERCY/song.json")}
  getListOfAlbum(){
    return this.http.get("assets/TP2_JSON_NAHSANG_MERCY/category.json")
  }
  getListOfAlbumVrai(){
    return this.http.get("assets/TP2_JSON_NAHSANG_MERCY/album.json")
  }
  async getDurationMusic(obj:any)
  {
  return (NativeAudio.getDuration({
    assetId: obj.idChanson
  }));


}

  async getfiles(son: any) {
    if (son.idCategori == "4") {
      this.categorie = "bensikin";
    } else {
      if (son.idCategori == "2") {
        this.categorie = "Bitkusi";
      } else {
        if (son.idCategori == "3") {
          this.categorie = "makossa";
        } else {
          if (son.idCategori == "1") {
            this.categorie = "afrourban";
          }
        }
      }
      try {
        const result = await Filesystem.readdir({
          path: '/Documents/zik_l3/'+ this.categorie,
          directory: Directory.ExternalStorage,
        });

        const files = result.files;
        files.forEach((file) => {
          this.nom.push(file.name);
          if (file.name == son.path) {
            this.chemin = file.uri;
            console.log("le chemin est bel: ", file.uri);
          }
        })
        console.log('la liste des dossiers: ', this.nom);
      } catch (error) {
        console.error('erreur lors de la recuperation: ', error);
      }

    }
  }
  async loadMusic(son: any) {
    await this.getfiles(son);
    console.log("le chemin est charger", this.chemin)
    return NativeAudio.preload({
      assetId: son.idChanson,
      assetPath: this.chemin,
      audioChannelNum: 1,
      isUrl: true
    });
  }
  

  pauseAudio(id: number){
    NativeAudio.pause({assetId: String(id)
    });
  }
  async stopAudio(son :any  ){
    await NativeAudio.stop({
      assetId:son.idChanson
    });
    await NativeAudio.unload({
      assetId: son.idChanson,

    });
    this.isPlaying = false;
  }
  async preview(son :any){
    try {
      await NativeAudio.stop({
        assetId: son.idChanson,
      });
  
      await this.playMusic(son);
      console.log('Piste précédente jouée avec succès.');
    } catch (error) {
      console.error('Erreur lors de la lecture de la piste précédente :', error);
    }
}
  async next(son :any){
  try {
    await NativeAudio.stop({
      assetId: this.enCours,
    });
    await this.playMusic(son);
    console.log('Piste suivante jouée avec succès.');
  } catch (error) {
    console.error('Erreur lors de la lecture de la piste suivante :', error);
  }

}

  async playMusic(son: any) {
   
    this.enCours = son.idChanson;
    await NativeAudio.play({
      assetId:son.idChanson,
      
    });
  }

  
  pauseSon(son:any)
  {
    return NativeAudio.pause({
      assetId: String(son.idChanson)
    });
  }

  resume(son:any)
  {
    return NativeAudio.resume({
      assetId: String(son.idChanson)
    })
  }

  ajouterVolume(son: any, vol:number)
  {
    NativeAudio.setVolume({
      assetId:son.idChanson.toString(),
      volume: vol
    });
  }


  getCurrentTime(id: Number) {
    return NativeAudio.getCurrentTime({ assetId: String(id) })
  }

  setVolume(id: number, vol: number) {
    NativeAudio.setVolume({
      assetId: "damso",
      volume: vol,
    });

  }

  dplayAudio(t: number = 0) {
    NativeAudio.play({
      assetId: "damso",
      time: t
    });
    // this.isPlaying = true;
  }
   async repeter(son:any){
  await NativeAudio.loop({
    assetId: son.idChanson.toString()
  });
}



  Unload() {
    NativeAudio.unload({
      assetId: "dam",
    });
  }








}
