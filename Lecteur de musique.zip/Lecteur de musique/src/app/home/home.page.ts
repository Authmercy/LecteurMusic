import { Component, OnInit } from '@angular/core';
import { CategoriesService } from "../providers/categories.service";
import { SongsService } from "../providers/songs.service";
import { LoadingController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { ElementRef, NgModule, ViewChild } from '@angular/core';
import { register } from 'swiper/element/bundle';
register();
import { IonicSlides,NavController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  pending: boolean= false
  Tfavoris: any[] = [];
  Tcategorie: any[] = [];
  private loader : any;
  Tsongs: any[] = [];
  isPlay= true;
  isPlaying :any ;
  pause: any = "pause"
  son: any;

  swiperModules = [IonicSlides];
  images = [
    {src: '../assets/imgs/afro.jpg'},
    {src: 'assets/imgs/bitkussi.jpg'},
    {src: 'assets/imgs/bensikin.jpg'},
    {src: 'assets/imgs/makossa.jpg'}
  ];
  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;

  logActiveIndex() {
    console.log(this.swiperRef?.nativeElement.swiper.activeIndex);
  }
  constructor(
    private song: SongsService,
    private pson: SongsService,
    private categorie: CategoriesService,
    private route: Router,
    private audioService: SongsService,
    private router: ActivatedRoute,
    private loadingCtrl: LoadingController
  ) { }

  async ngOnInit() {
    await this.presentLoading();
    this.song.getListOfAlbum().subscribe((rep: any) => {
      this.Tcategorie = rep;
      console.log(this.Tcategorie);
      this.pending = true;
 
    }, (err) => {
      console.log(err);
    });

    this.song.getListOfMusics().subscribe((rep: any) => {
      this.Tsongs = rep;
      console.log(this.Tsongs);

      this.Tfavoris = this.Tsongs.filter((song: any) => {
        return song.est_fav === "true";
      });
      console.log(this.Tfavoris);

    }, (err) => {
      console.log(err);
    });
    this.son = JSON.parse(localStorage.getItem('sonL') as string);
    
    this.pson.loadMusic(this.son);
    this.pson.playMusic(this.son);

  }
 
  details(musi: any) {
    localStorage.setItem("dt", JSON.stringify(musi));
    this.route.navigate(['onglets/home/dcategorie/lecture']);
  }

  async presentLoading() {
    this.loader = await this.loadingCtrl.create({
      message: 'Bonjour Toi',
       duration: 800,
      spinner: 'lines'
    });

    await this.loader.present();
  }

  // async onPlay(son:any){

  //   await this.audioService.loadAudio(son);
  //    this.audioService.playAudio();
  //  }


  dcat(cat: string) {
    localStorage.setItem("fn", JSON.stringify(cat));
    this.route.navigate(['onglets/home/dcategorie']);
  }
 
  play(son:any) {
     this.pson.loadMusic(son);
     this.pson.playMusic(son)
    this.isPlaying = true;
  }
  pauseSon() {
    {
     
      {
        
        this.pson.pauseAudio(this.son);
        this.isPlaying =false;
        
      }
      
    }
  }
  
 async start(son:any)
 {
  await this.pson.loadMusic(son);
  await this.pson.playMusic(son)
  this.isPlaying =true;
 }

  
  stop(son: any) {
    this.pson.stopAudio(son);
    // Votre logique pour arrêter complètement la lecture de la musique
    this.isPlaying = false;
  
  }}

