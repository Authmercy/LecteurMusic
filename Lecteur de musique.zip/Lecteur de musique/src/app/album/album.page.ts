import { Component, OnInit } from '@angular/core';
import { SongsService } from "../providers/songs.service";
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-album',
  templateUrl: './album.page.html',
  styleUrls: ['./album.page.scss'],
})
export class AlbumPage implements OnInit {
  listmusic: any[]=[];
  listalbum: any[]=[];
  album : any;
isPlaying :boolean = false;
  musics: any[]=[];
  loader: any;
  pending: boolean= false
 
  Tsongsrech: any[] = [];
  Tsongsalb: any[] = [];
  Tsongsartiste: any[] = [];

   
  constructor(
    private musicService: SongsService,
    private route: Router,
    private router: ActivatedRoute
  ) { }

  ngOnInit() {
    this.musicService.getListOfMusics().subscribe((rep : any)=>{
      console.log(rep);
    this.listmusic = rep;
    this.musics =rep;
    this.pending = true;
  },
    (err)=>{
      console.log(err);
    });
    this.musicService.getListOfAlbumVrai().subscribe((rep : any)=>{
      console.log(rep);
    this.listalbum= rep;
    this.album =rep;
    this.pending = true;
  
  }, (err)=>{
    console.log(err);
  });
  
  }
  
  onSearchChange(ev: any){
    console.log(ev.detail.value);
    let recherche: string = ev.detail.value;

    this.Tsongsalb = this.Tsongsartiste.filter(Artiste =>{
      let txt_search = Artiste;
      return txt_search.toLowerCase().indexOf(recherche.toLowerCase()) > -1;
    });
    console.log(this.Tsongsalb)
    }

    Listealb(album: any) {
      localStorage.setItem("al", JSON.stringify(album));
      this.route.navigate(['onglets/album/listealbum']);
    }

    

}
