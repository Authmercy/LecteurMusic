import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AlbumvraiPage } from './albumvrai.page';

const routes: Routes = [
  {
    path: '',
    component: AlbumvraiPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AlbumvraiPageRoutingModule {}
