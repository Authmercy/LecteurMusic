import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AlbumvraiPage } from './albumvrai.page';

describe('AlbumvraiPage', () => {
  let component: AlbumvraiPage;
  let fixture: ComponentFixture<AlbumvraiPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AlbumvraiPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
