import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AlbumvraiPageRoutingModule } from './albumvrai-routing.module';

import { AlbumvraiPage } from './albumvrai.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AlbumvraiPageRoutingModule
  ],
  declarations: [AlbumvraiPage]
})
export class AlbumvraiPageModule {}
