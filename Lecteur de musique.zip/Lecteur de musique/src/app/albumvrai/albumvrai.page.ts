import { Component, OnInit } from '@angular/core';
import { MusicService } from '../provider/music.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-albumvrai',
  templateUrl: './albumvrai.page.html',
  styleUrls: ['./albumvrai.page.scss'],
})
export class AlbumvraiPage implements OnInit {

  listmusic: any[]=[];
  listalbum: any[]=[];
  album : any;
isPlaying :boolean = false;
  musics: any[]=[];
  loader: any;
  pending: boolean= false
 
  constructor(private musicService:MusicService,private router: Router) {}


ngOnInit(){
  this.musicService.getListOfAlbumVrai().subscribe((rep : any)=>{
    console.log(rep);
  this.listmusic = rep;
  this.musics =rep;
  this.pending = true;
},
  (err)=>{
    console.log(err);
  });
  

}



onsearchChange(ev: any){
  console.log(ev);
      
  let recherche: string = ev.Title; 
  this.listmusic = this.musics.filter(musics =>{
  let txt_search = musics.Titre;
   return txt_search.toLowerCase().indexOf(recherche.toLowerCase()) > -1;
  }); 
          
  console.log(this.listmusic);
 
}
  
  filterItems(evt:any) {
    const searchTerm = evt.srcElement.value;
  
    if (!searchTerm) {
      return;
    }
    
  this.musics= this.listmusic.filter (musics=>{
    let txt_search = musics.Title;
    return txt_search.toLowerCase().indexOf(searchTerm.toLowerCase())> -1;
   });
   console.log(this.musics);
   
   }

   stockAlbum(obj:any){
    localStorage.setItem("ky",JSON.stringify(obj));
    
    this.router.navigate(['son-album'] ); 
  }

 

}


