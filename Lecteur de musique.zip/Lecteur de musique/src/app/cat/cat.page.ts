import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MusicService } from '../provider/music.service';

@Component({
  selector: 'app-cat',
  templateUrl: './cat.page.html',
  styleUrls: ['./cat.page.scss'],
})
export class CatPage implements OnInit {

  listmusic: any[]=[];
  listalbum: any[]=[];
  album : any;
isPlaying :boolean = false;
  musics: any[]=[];
  loader: any;
  pending: boolean= false
 
  constructor(private musicService:MusicService,private route: Router, private router: ActivatedRoute) {}
  ngOnInit(){
    const categorie = JSON.parse(localStorage.getItem('key') as string);
    this.musicService.getListOfMusics().subscribe((rep : any)=>{
      this.listmusic = rep;
      this.musics =this.listmusic.filter((x:any)=>x.idCategori == categorie.idCategori)
 console.log(this.musics) 
},
    (err)=>{
      console.log(err);
    });
    this.musicService.getListOfAlbum().subscribe((rep : any)=>{
      console.log(rep);
    this.listalbum= rep;
    this.album =rep;
    this.pending = true;
   
  
  
  
  
  }, (err)=>{
    console.log(err);
  });
  
  }
  
  
  
  onsearchChange(ev: any){
    console.log(ev);
        
    let recherche: string = ev.Title; 
    this.listmusic = this.musics.filter(musics =>{
    let txt_search = musics.Titre;
     return txt_search.toLowerCase().indexOf(recherche.toLowerCase()) > -1;
    }); 
            
    console.log(this.listmusic);
   
  }
    
    filterItems(evt:any) {
      const searchTerm = evt.srcElement.value;
    
      if (!searchTerm) {
        return;
      }
      
    this.musics= this.listmusic.filter (musics=>{
      let txt_search = musics.Title;
      return txt_search.toLowerCase().indexOf(searchTerm.toLowerCase())> -1;
     });
     console.log(this.musics);
     
     }
  
     voirplus(musics:any){
      localStorage.setItem("fn",JSON.stringify(musics));
      // this.valeur= this.router.snapshot.paramMap.get('id');
  console.log(musics);
      this.route.navigate(['son'] ); 
    }
    
getObject(album: any) {
  localStorage.setItem('key', JSON.stringify(album)) 
  
}
}
