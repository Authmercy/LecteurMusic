import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SonPage } from './son.page';

describe('SonPage', () => {
  let component: SonPage;
  let fixture: ComponentFixture<SonPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SonPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
