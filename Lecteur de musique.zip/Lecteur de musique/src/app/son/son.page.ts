import { Component, OnInit } from '@angular/core';
import { MusicService } from '../provider/music.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-son',
  templateUrl: './son.page.html',
  styleUrls: ['./son.page.scss'],
})
export class SonPage implements OnInit {

  isPlaying :any ;
  musics: any;
  listmusic1: any;
  loader: any;
  pause: any = "pause"
  son: any;
  vSon= 0.5
  mute: any="mute"
  duree: any
  stopMusic: any;
  tabson: any[]=[];
  repson: any;
  val= 0;
  indexCourent: number= 0
  fin=0
  isPlay= true
  idChanson = Number(this.route.snapshot.paramMap.get('idChanson'));
  isLoop: boolean =false;
  constructor(private pson:MusicService, private route : ActivatedRoute) { }

  
  async ngOnInit() {
    
    this.son = JSON.parse(localStorage.getItem('sonL') as string);
    
    this.pson.loadMusic(this.son);
    this.pson.playMusic(this.son);
    
    //this.pson.stopMusic(this.son);

    this.indexCourent= this.getIndex(this.son)

    console.log(this.indexCourent);
    this.start(this.son)



     setInterval(async () => {
      this.duree = (
        await this.pson.getDurationMusic(this.son)).duration;
      console.log("duree", this.duree)
    }, 10); 
   
  }

  

  

   t=setInterval(async ()=>{
   let time= (await this.pson.getDurationMusic(this.son)).duration
    this.val = this.val + (100/time)
    console.log('hello',this.val)
  console.log("oui", time)
  }, 1000);

  getIndex(obj:any)
  {
    console.log(this.tabson);
    let i = -1;
    this.tabson.forEach((item, index) => {
      if(item.idChanson == obj.idChanson ){
        i=index;
      }
      
    })
    return i;
  }


  pauseSon()
  {
    if ( this.pause== "pause")
    {
      this.pause = "play";
      this.pson.pauseSon(this.son);
      this.isPlaying =true;
      
    }
    else{
      this.pause = "pause";
      this.pson.resume(this.son);
     
      this.isPlaying =false;
    }
  }



 async start(son:any)
 {
  await this.pson.loadMusic(son);
  await this.pson.playMusic(son)
  this.isPlaying =true;
 }


 
 precedent(idChanson : any){
  if(!this.isLoop){
    this.idChanson= this.pson.preview(idChanson);
  }
  this.ngOnInit();
  this.isPlaying = true;
}
next(idChanson: any){
  if(!this.isLoop){
    this.idChanson = this.pson.next(idChanson);
  }
    this.ngOnInit();
    this.isPlaying =true;
}
  minimalVol(){
    this.pson.ajouterVolume(this.son,this.vSon -0.1);
    this.vSon -= 0.1;
  }

  maximalVol(){
    this.pson.ajouterVolume(this.son,this.vSon +0.1);
    this.vSon += 0.1;
  }

  muetVol(){
    if(
      this.mute == "mute"){
        this.mute = "high";
        this.pson.ajouterVolume(this.son, 0.0);
      }
      else{
        this.mute="mute";
        this.pson.ajouterVolume(this.son, this.vSon);
      }
  }
  repeter(obj:any){
    if(this.repson== 'repeat-outline'){
      this.repson = 'repeat-sharp';
      this.pson.repeter(obj);
    }else{
      this.repson = 'repeat-outline';
      this.pson.repeter(obj);
   
     
    }

  }

}
